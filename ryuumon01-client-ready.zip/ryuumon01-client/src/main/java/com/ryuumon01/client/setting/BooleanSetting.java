package com.ryuumon01.client.setting;

import java.util.function.Supplier;

public class BooleanSetting extends Setting<Boolean> {

    // Optional visibility predicate, e.g. only show "Zoom FOV" if Zoom is enabled.
    private Supplier<Boolean> visibilityPredicate = () -> true;

    public BooleanSetting(String name, String description, boolean defaultValue) {
        super(name, description, defaultValue);
    }

    public void toggle() {
        value = !value;
    }

    public BooleanSetting visibleIf(Supplier<Boolean> predicate) {
        this.visibilityPredicate = predicate;
        return this;
    }

    @Override
    public boolean isVisible() {
        return visibilityPredicate.get();
    }
}
