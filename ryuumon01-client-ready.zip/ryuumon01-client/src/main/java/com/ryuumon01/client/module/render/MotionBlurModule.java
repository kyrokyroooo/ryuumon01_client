package com.ryuumon01.client.module.render;

import com.ryuumon01.client.module.Category;
import com.ryuumon01.client.module.Module;
import com.ryuumon01.client.setting.NumberSetting;
import org.lwjgl.glfw.GLFW;

/**
 * Exposes the intensity value that a post-process shader (registered separately as a
 * core shader / ShaderEffect JSON under assets/ryuumon01-client/shaders/) reads each
 * frame to blend the previous frame's color target with the current one.
 *
 * This class intentionally only owns the *setting*, not the GL/shader plumbing —
 * wiring a custom PostEffectProcessor is render-pipeline-version-specific and should
 * be implemented against whichever exact 1.21.1 Fabric API build you compile against.
 * See assets/ryuumon01-client/shaders/motion_blur.json for the shader scaffold.
 */
public class MotionBlurModule extends Module {

    private final NumberSetting intensity =
            new NumberSetting("Intensity", "Blend strength between current and previous frame", 35, 0, 90, 1, true);

    public MotionBlurModule() {
        super("MotionBlur", "Adjustable motion blur for smoother camera movement", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
        addSetting(intensity);
    }

    /** 0.0 - 0.9 blend factor consumed by the post-process shader each frame. */
    public float getBlendFactor() {
        return (float) (intensity.getValue() / 100.0);
    }
}
