package com.ryuumon01.client.mixin;

import com.ryuumon01.client.Ryuumon01Client;
import com.ryuumon01.client.module.render.ZoomModule;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Applies the Zoom module's smoothed FOV multiplier during FOV calculation.
 *
 * Exact injection target/signature (method name, descriptor, local variable index)
 * depends on the Yarn mappings build you compile against — verify against
 * GameRenderer#getFov in your local mappings before building, since these shift
 * between snapshot mapping revisions.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

    @ModifyVariable(method = "getFov", at = @At("RETURN"))
    private double applyZoom(double fov) {
        ZoomModule zoom = Ryuumon01Client.getInstance().getModuleManager()
                .getModules(com.ryuumon01.client.module.Category.RENDER)
                .stream()
                .filter(m -> m instanceof ZoomModule)
                .map(m -> (ZoomModule) m)
                .findFirst()
                .orElse(null);

        if (zoom == null || !zoom.isEnabled()) return fov;
        return fov * zoom.getFovMultiplier(1.0f);
    }
}
