package com.ryuumon01.client.module.render;

import com.ryuumon01.client.Ryuumon01Client;
import com.ryuumon01.client.module.Category;
import com.ryuumon01.client.module.Module;
import com.ryuumon01.client.setting.BooleanSetting;
import com.ryuumon01.client.setting.ColorSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;
import java.util.List;

public class HudModule extends Module {

    private final BooleanSetting showFps = new BooleanSetting("FPS", "Show frames per second", true);
    private final BooleanSetting showCoords = new BooleanSetting("Coordinates", "Show player coordinates", true);
    private final BooleanSetting showDirection = new BooleanSetting("Direction", "Show cardinal direction", true);
    private final BooleanSetting showPing = new BooleanSetting("Ping", "Show connection latency", true);
    private final BooleanSetting showArmor = new BooleanSetting("Armor", "Show equipped armor status", true);
    private final BooleanSetting showModuleList = new BooleanSetting("Module List", "Show active module arraylist", true);
    private final ColorSetting accentColor = new ColorSetting("Accent Color", "HUD accent color", 0xFF00E5FF);

    // Drag state for the info panel; module list position is independent and anchored top-right.
    private int panelX = 6;
    private int panelY = 6;
    private boolean dragging = false;
    private int dragOffsetX, dragOffsetY;

    public HudModule() {
        super("HUD", "Draggable overlay: FPS, CPS, ping, coords, direction, armor, module list", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
        addSetting(showFps);
        addSetting(showCoords);
        addSetting(showDirection);
        addSetting(showPing);
        addSetting(showArmor);
        addSetting(showModuleList);
        addSetting(accentColor);
    }

    @Override
    protected void onEnable() {
        // HUD is on by default and non-invasive; nothing to allocate.
    }

    @Override
    public void onRenderHud(DrawContext context, float tickDelta) {
        if (client.player == null || client.options.hudHidden) return;

        int color = accentColor.tickAndGetColor(tickDelta / 20f);
        int y = panelY;
        int x = panelX;
        int lineHeight = 10;

        if (showFps.getValue()) {
            drawLine(context, x, y, "FPS: " + client.getCurrentFps(), color);
            y += lineHeight;
        }
        if (showPing.getValue()) {
            drawLine(context, x, y, "Ping: " + getPlayerPing() + "ms", color);
            y += lineHeight;
        }
        if (showCoords.getValue()) {
            ClientPlayerEntity p = client.player;
            String coords = String.format("XYZ: %.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ());
            drawLine(context, x, y, coords, color);
            y += lineHeight;
        }
        if (showDirection.getValue()) {
            drawLine(context, x, y, "Facing: " + getFacingDirection(), color);
            y += lineHeight;
        }
        if (showArmor.getValue()) {
            drawLine(context, x, y, "Armor: " + getArmorSummary(), color);
            y += lineHeight;
        }

        if (showModuleList.getValue()) {
            renderModuleList(context, tickDelta);
        }
    }

    private void renderModuleList(DrawContext context, float tickDelta) {
        List<com.ryuumon01.client.module.Module> active = Ryuumon01Client.getInstance()
                .getModuleManager().getModules().stream()
                .filter(com.ryuumon01.client.module.Module::isEnabled)
                .sorted(Comparator.comparingInt(m -> -client.textRenderer.getWidth(m.getName())))
                .toList();

        int screenWidth = client.getWindow().getScaledWidth();
        int y = 6;
        for (com.ryuumon01.client.module.Module module : active) {
            int width = client.textRenderer.getWidth(module.getName());
            int x = screenWidth - width - 6;
            int color = ColorSetting.hsvToArgb((System.currentTimeMillis() / 20f + y * 4) % 360f, 0.8f, 1f, 255);
            context.drawTextWithShadow(client.textRenderer, module.getName(), x, y, color);
            y += 10;
        }
    }

    private void drawLine(DrawContext context, int x, int y, String text, int color) {
        context.fill(x - 2, y - 1, x + client.textRenderer.getWidth(text) + 2, y + 9, 0x60000000);
        context.drawTextWithShadow(client.textRenderer, text, x, y, color);
    }

    private int getPlayerPing() {
        if (client.getNetworkHandler() == null || client.player == null) return 0;
        PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
        return entry != null ? entry.getLatency() : 0;
    }

    private String getFacingDirection() {
        Direction dir = client.player.getHorizontalFacing();
        return switch (dir) {
            case NORTH -> "N";
            case SOUTH -> "S";
            case EAST -> "E";
            case WEST -> "W";
            default -> "-";
        };
    }

    private String getArmorSummary() {
        int total = 0;
        int count = 0;
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = client.player.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                count++;
                total += stack.getMaxDamage() - stack.getDamage();
            }
        }
        return count + "/4 pieces";
    }

    // --- Drag handling, called from the HUD editor overlay (not the ClickGUI) ---

    public void startDrag(int mouseX, int mouseY) {
        dragging = true;
        dragOffsetX = mouseX - panelX;
        dragOffsetY = mouseY - panelY;
    }

    public void updateDrag(int mouseX, int mouseY, int screenWidth, int screenHeight) {
        if (!dragging) return;
        panelX = MathHelper.clamp(mouseX - dragOffsetX, 0, screenWidth - 100);
        panelY = MathHelper.clamp(mouseY - dragOffsetY, 0, screenHeight - 60);
    }

    public void stopDrag() {
        dragging = false;
    }
}
