package com.ryuumon01.client.module;

public enum Category {
    RENDER("Render"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    UTILITY("Utility");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
