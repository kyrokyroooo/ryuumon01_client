package com.ryuumon01.client.module.render;

import com.ryuumon01.client.module.Category;
import com.ryuumon01.client.module.Module;
import com.ryuumon01.client.setting.NumberSetting;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * Smoothly interpolates the player's FOV down toward a target zoom factor while the
 * keybind is held, then eases back to normal on release. Purely visual/client-side.
 */
public class ZoomModule extends Module {

    private final NumberSetting zoomFactor =
            new NumberSetting("Zoom Factor", "How far to zoom in", 4, 1.5, 10, 0.5, false);
    private final NumberSetting smoothing =
            new NumberSetting("Smoothing", "Interpolation speed toward target zoom", 6, 1, 20, 1, true);

    private double currentFovMultiplier = 1.0;
    private boolean held = false;

    public ZoomModule() {
        super("Zoom", "Smooth camera zoom while the keybind is held", Category.RENDER, GLFW.GLFW_KEY_C);
        addSetting(zoomFactor);
        addSetting(smoothing);
    }

    @Override
    protected void onDisable() {
        held = false;
        currentFovMultiplier = 1.0;
    }

    public void setHeld(boolean held) {
        this.held = held;
    }

    /**
     * Called every render frame by the mixin/event hook responsible for FOV calculation.
     * Returns the multiplier to apply on top of the player's base FOV.
     */
    public double getFovMultiplier(float tickDelta) {
        if (!isEnabled()) return 1.0;

        double target = held ? 1.0 / zoomFactor.getValue() : 1.0;
        double speed = smoothing.getValue() * (tickDelta / 20f);
        currentFovMultiplier = MathHelper.lerp(Math.min(1.0, speed), currentFovMultiplier, target);
        return currentFovMultiplier;
    }

    public boolean isHeld() {
        return held;
    }
}
