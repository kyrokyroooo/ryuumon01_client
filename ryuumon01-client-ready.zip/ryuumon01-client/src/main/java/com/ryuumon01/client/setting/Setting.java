package com.ryuumon01.client.setting;

/**
 * Base class for all configurable module settings.
 * Concrete settings (Boolean, Number, Mode, Keybind, Color) extend this.
 */
public abstract class Setting<T> {

    private final String name;
    private final String description;
    protected T value;

    protected Setting(String name, String description, T defaultValue) {
        this.name = name;
        this.description = description;
        this.value = defaultValue;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    /**
     * Whether this setting should currently render in the GUI.
     * Overridden by settings that only appear when a parent toggle is enabled.
     */
    public boolean isVisible() {
        return true;
    }
}
