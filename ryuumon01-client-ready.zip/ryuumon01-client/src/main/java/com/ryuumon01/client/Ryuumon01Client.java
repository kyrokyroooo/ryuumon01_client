package com.ryuumon01.client;

import com.ryuumon01.client.gui.Ryuumon01ClickGUI;
import com.ryuumon01.client.module.ModuleManager;
import com.ryuumon01.client.sound.SoundManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Client entrypoint. Wires up module registration, the sound manager, the GUI open
 * keybind, per-tick module updates, and the HUD render callback.
 */
public class Ryuumon01Client implements ClientModInitializer {

    private static Ryuumon01Client instance;

    private final ModuleManager moduleManager = new ModuleManager();
    private final SoundManager soundManager = new SoundManager();

    private KeyBinding guiKeybind;

    public static Ryuumon01Client getInstance() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;

        moduleManager.registerAll();

        guiKeybind = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ryuumon01-client.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.ryuumon01-client.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
        HudRenderCallback.EVENT.register((context, tickDelta) -> moduleManager.renderHudAll(context, tickDelta.getTickProgress(false)));
    }

    private void onClientTick(MinecraftClient client) {
        while (guiKeybind.wasPressed()) {
            if (client.currentScreen == null) {
                client.setScreen(new Ryuumon01ClickGUI());
            } else if (client.currentScreen instanceof Ryuumon01ClickGUI) {
                client.setScreen(null);
            }
        }
        moduleManager.tickAll();
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public SoundManager getSoundManager() {
        return soundManager;
    }
}
