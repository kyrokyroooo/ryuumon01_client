package com.ryuumon01.client.setting;

import java.util.List;

public class ModeSetting extends Setting<String> {

    private final List<String> options;
    private boolean expanded = false;

    public ModeSetting(String name, String description, List<String> options, String defaultValue) {
        super(name, description, defaultValue);
        this.options = options;
    }

    public List<String> getOptions() {
        return options;
    }

    public void cycleNext() {
        int idx = options.indexOf(getValue());
        setValue(options.get((idx + 1) % options.size()));
    }

    public boolean isExpanded() {
        return expanded;
    }

    public void toggleExpanded() {
        expanded = !expanded;
    }
}
