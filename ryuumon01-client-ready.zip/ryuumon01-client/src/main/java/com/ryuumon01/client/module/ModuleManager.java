package com.ryuumon01.client.module;

import com.ryuumon01.client.module.render.FullbrightModule;
import com.ryuumon01.client.module.render.HudModule;
import com.ryuumon01.client.module.render.MotionBlurModule;
import com.ryuumon01.client.module.render.NoRenderModule;
import com.ryuumon01.client.module.render.ZoomModule;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Central registry for all modules. Handles registration, category grouping,
 * keybind dispatch, and per-tick / per-frame iteration.
 */
public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();
    private final Map<Category, List<Module>> byCategory = new EnumMap<>(Category.class);

    public void registerAll() {
        // Render / visual modules
        register(new HudModule());
        register(new FullbrightModule());
        register(new ZoomModule());
        register(new MotionBlurModule());
        register(new NoRenderModule());

        // Additional categories (Movement, Player, Utility) are ready to receive
        // modules the same way — just instantiate and call register(...) here.
    }

    private void register(Module module) {
        modules.add(module);
        byCategory.computeIfAbsent(module.getCategory(), c -> new ArrayList<>()).add(module);
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    public List<Module> getModules(Category category) {
        return Collections.unmodifiableList(byCategory.getOrDefault(category, Collections.emptyList()));
    }

    public Optional<Module> getByName(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst();
    }

    /** Call from a key-press hook (outside the GUI) to trigger module hotkeys. */
    public void handleKeyPress(int keyCode) {
        for (Module module : modules) {
            if (module.getKeybind().getValue() == keyCode) {
                module.toggle();
            }
        }
    }

    public void tickAll() {
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.onTick();
            }
        }
    }

    public void renderAll(float tickDelta) {
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.onRender(tickDelta);
            }
        }
    }

    public void renderHudAll(net.minecraft.client.gui.DrawContext context, float tickDelta) {
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.onRenderHud(context, tickDelta);
            }
        }
    }
}
