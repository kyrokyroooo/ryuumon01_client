package com.ryuumon01.client.setting;

public class NumberSetting extends Setting<Double> {

    private final double min;
    private final double max;
    private final double increment;
    private final boolean isInteger;

    public NumberSetting(String name, String description, double defaultValue,
                          double min, double max, double increment, boolean isInteger) {
        super(name, description, clamp(defaultValue, min, max));
        this.min = min;
        this.max = max;
        this.increment = increment;
        this.isInteger = isInteger;
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public double getIncrement() {
        return increment;
    }

    public boolean isInteger() {
        return isInteger;
    }

    /** Converts a normalized slider position (0.0 - 1.0) into a snapped value. */
    public void setFromSliderPercent(double percent) {
        double raw = min + (max - min) * clamp(percent, 0, 1);
        double snapped = Math.round(raw / increment) * increment;
        setValue(clamp(isInteger ? Math.round(snapped) : snapped, min, max));
    }

    public double getSliderPercent() {
        return (getValue() - min) / (max - min);
    }

    public String getDisplayValue() {
        return isInteger ? String.valueOf(Math.round(getValue())) : String.format("%.2f", getValue());
    }
}
