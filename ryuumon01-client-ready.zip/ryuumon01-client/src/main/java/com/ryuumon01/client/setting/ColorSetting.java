package com.ryuumon01.client.setting;

public class ColorSetting extends Setting<Integer> {

    private boolean chroma = false;
    private float chromaSpeed = 1.0f;
    // Rotating hue used when chroma mode is active; advanced by the GUI render tick.
    private float chromaHue = 0f;

    public ColorSetting(String name, String description, int argb) {
        super(name, description, argb);
    }

    public boolean isChroma() {
        return chroma;
    }

    public void setChroma(boolean chroma) {
        this.chroma = chroma;
    }

    public float getChromaSpeed() {
        return chromaSpeed;
    }

    public void setChromaSpeed(float speed) {
        this.chromaSpeed = speed;
    }

    /** Called once per frame by the GUI to advance the hue cycle when chroma is active. */
    public int tickAndGetColor(float deltaSeconds) {
        if (!chroma) return getValue();
        chromaHue = (chromaHue + deltaSeconds * chromaSpeed * 60f) % 360f;
        return hsvToArgb(chromaHue, 0.85f, 1.0f, (getValue() >>> 24) & 0xFF);
    }

    public static int hsvToArgb(float hue, float saturation, float brightness, int alpha) {
        int rgb = java.awt.Color.HSBtoRGB(hue / 360f, saturation, brightness);
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }
}
