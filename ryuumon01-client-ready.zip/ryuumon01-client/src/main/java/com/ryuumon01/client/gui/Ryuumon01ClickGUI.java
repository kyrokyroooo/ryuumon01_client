package com.ryuumon01.client.gui;

import com.ryuumon01.client.Ryuumon01Client;
import com.ryuumon01.client.module.Category;
import com.ryuumon01.client.module.Module;
import com.ryuumon01.client.setting.BooleanSetting;
import com.ryuumon01.client.setting.ColorSetting;
import com.ryuumon01.client.setting.KeybindSetting;
import com.ryuumon01.client.setting.ModeSetting;
import com.ryuumon01.client.setting.NumberSetting;
import com.ryuumon01.client.setting.Setting;
import com.ryuumon01.client.sound.SoundManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Dark, semi-transparent ClickGUI with rounded panels, a live search bar, and
 * hover/click/scroll sound feedback. Bound to RIGHT_SHIFT by default (see
 * Ryuumon01Client#GUI_KEYBIND).
 *
 * Panel positions are stored per-category so re-opening the GUI keeps your layout.
 */
public class Ryuumon01ClickGUI extends Screen {

    private static final int PANEL_WIDTH = 140;
    private static final int HEADER_HEIGHT = 22;
    private static final int ROW_HEIGHT = 20;
    private static final int BG_PANEL = 0xCC15161B;
    private static final int BG_HEADER = 0xE01B1D24;
    private static final int ACCENT = 0xFF7C4DFF;
    private static final int TEXT_PRIMARY = 0xFFE6E6EA;
    private static final int TEXT_MUTED = 0xFF8A8D98;

    private final Map<Category, CategoryPanel> panels = new EnumMap<>(Category.class);
    private final SoundManager soundManager = Ryuumon01Client.getInstance().getSoundManager();

    private TextFieldWidget searchField;
    private String searchQuery = "";

    private Object hoveredThisFrame = null;

    public Ryuumon01ClickGUI() {
        super(Text.literal("Ryuumon01 Client"));
    }

    @Override
    protected void init() {
        int startX = 20;
        int startY = 20;
        int col = 0;
        for (Category category : Category.values()) {
            CategoryPanel panel = panels.computeIfAbsent(category,
                    c -> new CategoryPanel(c, startX + col * (PANEL_WIDTH + 16), startY));
            col++;
        }

        searchField = new TextFieldWidget(textRenderer, width / 2 - 100, 4, 200, 16, Text.literal("Search"));
        searchField.setPlaceholder(Text.literal("Search modules..."));
        searchField.setChangedListener(text -> searchQuery = text.toLowerCase());
        addSelectableChild(searchField);
        setInitialFocus(searchField);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float tickDelta) {
        // Dim the world behind the GUI slightly instead of a full vanilla blur backdrop
        // (avoids the frame hit of a real gaussian pass on lower-end GPUs).
        context.fill(0, 0, width, height, 0x88000000);

        hoveredThisFrame = null;

        for (CategoryPanel panel : panels.values()) {
            panel.render(context, mouseX, mouseY, tickDelta);
        }

        searchField.render(context, mouseX, mouseY, tickDelta);
        soundManager.playHover(hoveredThisFrame);

        super.render(context, mouseX, mouseY, tickDelta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        boolean consumed = searchField.mouseClicked(mouseX, mouseY, button);
        for (CategoryPanel panel : panels.values()) {
            if (panel.mouseClicked(mouseX, mouseY, button)) {
                soundManager.playClick();
                consumed = true;
            }
        }
        return consumed || super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        for (CategoryPanel panel : panels.values()) {
            if (panel.mouseDragged(mouseX, mouseY, button, deltaX, deltaY)) return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (CategoryPanel panel : panels.values()) {
            panel.mouseReleased(mouseX, mouseY, button);
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (CategoryPanel panel : panels.values()) {
            if (panel.mouseScrolled(mouseX, mouseY, verticalAmount)) {
                soundManager.playScroll();
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        for (CategoryPanel panel : panels.values()) {
            if (panel.keyPressed(keyCode)) return true;
        }
        if (searchField.isFocused() && searchField.keyPressed(keyCode, scanCode, modifiers)) return true;
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchField.isFocused()) return searchField.charTyped(chr, modifiers);
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ------------------------------------------------------------------
    // Inner class: one draggable/scrollable panel per module category.
    // ------------------------------------------------------------------

    private class CategoryPanel {

        final Category category;
        int x, y;
        boolean collapsed = false;
        boolean dragging = false;
        int dragOffsetX, dragOffsetY;
        double scrollOffset = 0;

        // Which module's settings dropdown is expanded, if any.
        Module expandedModule = null;
        KeybindSetting listeningKeybind = null;

        CategoryPanel(Category category, int x, int y) {
            this.category = category;
            this.x = x;
            this.y = y;
        }

        List<Module> visibleModules() {
            List<Module> result = new ArrayList<>();
            for (Module m : Ryuumon01Client.getInstance().getModuleManager().getModules(category)) {
                if (searchQuery.isEmpty() || m.getName().toLowerCase().contains(searchQuery)) {
                    result.add(m);
                }
            }
            return result;
        }

        void render(DrawContext context, int mouseX, int mouseY, float tickDelta) {
            List<Module> modules = visibleModules();
            if (modules.isEmpty() && !searchQuery.isEmpty()) return;

            int panelHeight = HEADER_HEIGHT;
            if (!collapsed) {
                for (Module m : modules) {
                    panelHeight += ROW_HEIGHT;
                    if (m == expandedModule) {
                        panelHeight += visibleSettings(m).size() * ROW_HEIGHT;
                    }
                }
            }

            // Header
            boolean headerHovered = isHovered(mouseX, mouseY, x, y, PANEL_WIDTH, HEADER_HEIGHT);
            if (headerHovered) hoveredThisFrame = this;
            context.fill(x, y, x + PANEL_WIDTH, y + HEADER_HEIGHT, BG_HEADER);
            context.drawTextWithShadow(textRenderer, category.getDisplayName(), x + 8, y + 7, TEXT_PRIMARY);
            context.drawTextWithShadow(textRenderer, collapsed ? "+" : "-", x + PANEL_WIDTH - 14, y + 7, TEXT_MUTED);

            if (collapsed) return;

            context.fill(x, y + HEADER_HEIGHT, x + PANEL_WIDTH, y + panelHeight, BG_PANEL);

            int rowY = y + HEADER_HEIGHT;
            for (Module module : modules) {
                boolean rowHovered = isHovered(mouseX, mouseY, x, rowY, PANEL_WIDTH, ROW_HEIGHT);
                if (rowHovered) hoveredThisFrame = module;

                int textColor = module.isEnabled() ? ACCENT : TEXT_PRIMARY;
                if (module.isEnabled()) {
                    context.fill(x, rowY, x + 3, rowY + ROW_HEIGHT, ACCENT);
                }
                context.drawTextWithShadow(textRenderer, module.getName(), x + 10, rowY + 6, textColor);
                if (!module.getSettings().isEmpty()) {
                    context.drawTextWithShadow(textRenderer, module == expandedModule ? "v" : ">", x + PANEL_WIDTH - 14, rowY + 6, TEXT_MUTED);
                }
                rowY += ROW_HEIGHT;

                if (module == expandedModule) {
                    for (Setting<?> setting : visibleSettings(module)) {
                        renderSetting(context, setting, x, rowY, mouseX, mouseY);
                        rowY += ROW_HEIGHT;
                    }
                }
            }
        }

        List<Setting<?>> visibleSettings(Module module) {
            List<Setting<?>> result = new ArrayList<>();
            for (Setting<?> s : module.getSettings()) {
                if (s.isVisible()) result.add(s);
            }
            return result;
        }

        void renderSetting(DrawContext context, Setting<?> setting, int panelX, int rowY, int mouseX, int mouseY) {
            context.fill(panelX, rowY, panelX + PANEL_WIDTH, rowY + ROW_HEIGHT, 0xB0101115);
            boolean hovered = isHovered(mouseX, mouseY, panelX, rowY, PANEL_WIDTH, ROW_HEIGHT);
            if (hovered) hoveredThisFrame = setting;

            if (setting instanceof BooleanSetting bs) {
                int boxColor = bs.getValue() ? ACCENT : 0xFF3A3D48;
                context.fill(panelX + PANEL_WIDTH - 24, rowY + 5, panelX + PANEL_WIDTH - 10, rowY + 15, boxColor);
                context.drawTextWithShadow(textRenderer, bs.getName(), panelX + 12, rowY + 6, TEXT_PRIMARY);

            } else if (setting instanceof NumberSetting ns) {
                context.drawTextWithShadow(textRenderer, ns.getName() + ": " + ns.getDisplayValue(), panelX + 12, rowY + 6, TEXT_PRIMARY);
                int barX = panelX + 12;
                int barY = rowY + 16;
                int barW = PANEL_WIDTH - 24;
                context.fill(barX, barY, barX + barW, barY + 2, 0xFF3A3D48);
                int fillW = (int) (barW * ns.getSliderPercent());
                context.fill(barX, barY, barX + fillW, barY + 2, ACCENT);

            } else if (setting instanceof ModeSetting ms) {
                context.drawTextWithShadow(textRenderer, ms.getName() + ": " + ms.getValue(), panelX + 12, rowY + 6, TEXT_PRIMARY);

            } else if (setting instanceof KeybindSetting ks) {
                String label = ks.isListening() ? "..." : ks.getKeyName();
                context.drawTextWithShadow(textRenderer, ks.getName(), panelX + 12, rowY + 6, TEXT_PRIMARY);
                context.drawTextWithShadow(textRenderer, label, panelX + PANEL_WIDTH - 10 - textRenderer.getWidth(label), rowY + 6, ACCENT);

            } else if (setting instanceof ColorSetting cs) {
                context.drawTextWithShadow(textRenderer, cs.getName(), panelX + 12, rowY + 6, TEXT_PRIMARY);
                int swatchColor = cs.tickAndGetColor(0.05f);
                context.fill(panelX + PANEL_WIDTH - 24, rowY + 5, panelX + PANEL_WIDTH - 10, rowY + 15, swatchColor);
            }
        }

        boolean isHovered(int mouseX, int mouseY, int rx, int ry, int rw, int rh) {
            return mouseX >= rx && mouseX <= rx + rw && mouseY >= ry && mouseY <= ry + rh;
        }

        boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (isHovered((int) mouseX, (int) mouseY, x, y, PANEL_WIDTH, HEADER_HEIGHT)) {
                if (button == 1) {
                    collapsed = !collapsed;
                } else {
                    dragging = true;
                    dragOffsetX = (int) mouseX - x;
                    dragOffsetY = (int) mouseY - y;
                }
                return true;
            }
            if (collapsed) return false;

            int rowY = y + HEADER_HEIGHT;
            for (Module module : visibleModules()) {
                if (isHovered((int) mouseX, (int) mouseY, x, rowY, PANEL_WIDTH, ROW_HEIGHT)) {
                    if (button == 0) {
                        module.toggle();
                    } else if (button == 1 && !module.getSettings().isEmpty()) {
                        expandedModule = (expandedModule == module) ? null : module;
                    }
                    return true;
                }
                rowY += ROW_HEIGHT;

                if (module == expandedModule) {
                    for (Setting<?> setting : visibleSettings(module)) {
                        if (isHovered((int) mouseX, (int) mouseY, x, rowY, PANEL_WIDTH, ROW_HEIGHT)) {
                            handleSettingClick(setting, mouseX, button);
                            return true;
                        }
                        rowY += ROW_HEIGHT;
                    }
                }
            }
            return false;
        }

        void handleSettingClick(Setting<?> setting, double mouseX, int button) {
            if (setting instanceof BooleanSetting bs) {
                bs.toggle();
            } else if (setting instanceof NumberSetting ns) {
                double percent = (mouseX - (x + 12)) / (double) (PANEL_WIDTH - 24);
                ns.setFromSliderPercent(percent);
            } else if (setting instanceof ModeSetting ms) {
                ms.cycleNext();
            } else if (setting instanceof KeybindSetting ks) {
                listeningKeybind = ks;
                ks.startListening();
            } else if (setting instanceof ColorSetting cs) {
                cs.setChroma(!cs.isChroma());
            }
        }

        boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
            if (dragging) {
                x = (int) mouseX - dragOffsetX;
                y = (int) mouseY - dragOffsetY;
                return true;
            }
            // Live-drag number sliders while the mouse button is held over them.
            if (button == 0 && expandedModule != null) {
                int rowY = y + HEADER_HEIGHT + visibleModules().indexOf(expandedModule) * ROW_HEIGHT + ROW_HEIGHT;
                for (Setting<?> setting : visibleSettings(expandedModule)) {
                    if (setting instanceof NumberSetting ns && isHovered((int) mouseX, (int) mouseY, x, rowY, PANEL_WIDTH, ROW_HEIGHT)) {
                        double percent = (mouseX - (x + 12)) / (double) (PANEL_WIDTH - 24);
                        ns.setFromSliderPercent(percent);
                        return true;
                    }
                    rowY += ROW_HEIGHT;
                }
            }
            return false;
        }

        void mouseReleased(double mouseX, double mouseY, int button) {
            dragging = false;
        }

        boolean mouseScrolled(double mouseX, double mouseY, double amount) {
            if (isHovered((int) mouseX, (int) mouseY, x, y, PANEL_WIDTH, HEADER_HEIGHT + 200)) {
                scrollOffset -= amount * ROW_HEIGHT;
                return true;
            }
            return false;
        }

        boolean keyPressed(int keyCode) {
            if (listeningKeybind != null) {
                listeningKeybind.bind(keyCode);
                listeningKeybind = null;
                return true;
            }
            return false;
        }
    }
}
