package com.ryuumon01.client.module.render;

import com.ryuumon01.client.module.Category;
import com.ryuumon01.client.module.Module;
import com.ryuumon01.client.setting.BooleanSetting;
import org.lwjgl.glfw.GLFW;

/**
 * Pure visual-comfort toggles. Each flag here is read by a matching mixin injection
 * point (e.g. GameRendererMixin#renderHurtCamera, ParticleManagerMixin#addParticle)
 * which early-returns when the flag is set. No gameplay state is altered — only
 * what gets drawn locally.
 */
public class NoRenderModule extends Module {

    private final BooleanSetting hurtCam = new BooleanSetting("No Hurt Cam", "Disable damage screen shake", true);
    private final BooleanSetting fireOverlay = new BooleanSetting("No Fire Overlay", "Hide the full-screen fire overlay", true);
    private final BooleanSetting explosionParticles = new BooleanSetting("No Explosion Particles", "Hide explosion particle clutter", false);
    private final BooleanSetting blindness = new BooleanSetting("No Blindness", "Remove the blindness vision overlay", false);

    public NoRenderModule() {
        super("NoRender", "Toggle off distracting screen effects", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
        addSetting(hurtCam);
        addSetting(fireOverlay);
        addSetting(explosionParticles);
        addSetting(blindness);
    }

    public boolean hideHurtCam() {
        return isEnabled() && hurtCam.getValue();
    }

    public boolean hideFireOverlay() {
        return isEnabled() && fireOverlay.getValue();
    }

    public boolean hideExplosionParticles() {
        return isEnabled() && explosionParticles.getValue();
    }

    public boolean hideBlindness() {
        return isEnabled() && blindness.getValue();
    }
}
