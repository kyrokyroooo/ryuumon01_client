package com.ryuumon01.client.module.render;

import com.ryuumon01.client.module.Category;
import com.ryuumon01.client.module.Module;
import com.ryuumon01.client.setting.NumberSetting;
import org.lwjgl.glfw.GLFW;

/**
 * Overrides the client-side gamma option while enabled and restores the player's
 * original setting on disable. Purely a local render/vision setting — affects
 * nothing sent to the server and gives no gameplay advantage over other players
 * beyond what any vanilla brightness slider already allows.
 *
 * Note: many servers disable or flag unusual gamma values via resource-pack-level
 * enforcement; this only changes the client option, nothing more.
 */
public class FullbrightModule extends Module {

    private final NumberSetting gammaOverride =
            new NumberSetting("Gamma", "Gamma level while enabled", 100, 1, 100, 1, true);

    private double previousGamma;

    public FullbrightModule() {
        super("Fullbright", "Overrides gamma for clearer vision in dark areas", Category.RENDER, GLFW.GLFW_KEY_UNKNOWN);
        addSetting(gammaOverride);
    }

    @Override
    protected void onEnable() {
        previousGamma = client.options.getGamma().getValue();
        client.options.getGamma().setValue(gammaOverride.getValue());
    }

    @Override
    public void onTick() {
        // Keep it pinned in case another mod/config screen resets it while active.
        client.options.getGamma().setValue(gammaOverride.getValue());
    }

    @Override
    protected void onDisable() {
        client.options.getGamma().setValue(previousGamma);
    }
}
