package com.ryuumon01.client.module;

import com.ryuumon01.client.setting.KeybindSetting;
import com.ryuumon01.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class for every toggleable feature. Subclasses implement onEnable/onDisable/onTick
 * as needed and register their settings via addSetting(...) in their constructor.
 */
public abstract class Module {

    protected final MinecraftClient client = MinecraftClient.getInstance();

    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private final KeybindSetting keybind;

    private boolean enabled;

    protected Module(String name, String description, Category category, int defaultKey) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.keybind = new KeybindSetting("Keybind", "Toggle key for " + name, defaultKey);
    }

    protected void addSetting(Setting<?> setting) {
        settings.add(setting);
    }

    public List<Setting<?>> getSettings() {
        return settings;
    }

    public KeybindSetting getKeybind() {
        return keybind;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean state) {
        if (state == enabled) return;
        enabled = state;
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
    }

    /** Called once when the module is turned on. Override to hook resources / send chat feedback. */
    protected void onEnable() {}

    /** Called once when the module is turned off. Override to release resources / reset state. */
    protected void onDisable() {}

    /** Called every client tick while enabled. Override in movement/player modules. */
    public void onTick() {}

    /** Called every render frame while enabled (after world render). Override in render modules. */
    public void onRender(float tickDelta) {}

    /** Called every frame for HUD-style overlays drawn directly to screen space. */
    public void onRenderHud(net.minecraft.client.gui.DrawContext context, float tickDelta) {}
}
