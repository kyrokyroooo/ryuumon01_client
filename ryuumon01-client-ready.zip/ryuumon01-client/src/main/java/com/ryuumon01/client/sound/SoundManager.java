package com.ryuumon01.client.sound;

import com.ryuumon01.client.setting.BooleanSetting;
import com.ryuumon01.client.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/**
 * Dedicated low-latency UI sound feedback engine.
 *
 * Sounds are registered as custom SoundEvents pointing at .ogg files bundled under
 * assets/ryuumon01-client/sounds/ (see sounds.json). Playback goes through the vanilla
 * MASTER sound category at a fixed low volume scaled by the user's UI Sound Volume setting,
 * so it never interferes with in-game music/ambience channels.
 */
public class SoundManager {

    public static final BooleanSetting UI_SOUND_ENABLED =
            new BooleanSetting("UI Sound", "Enable ClickGUI sound feedback", true);

    public static final NumberSetting UI_SOUND_VOLUME =
            new NumberSetting("UI Volume", "Volume of ClickGUI sound feedback", 60, 0, 100, 1, true);

    private static final Identifier HOVER_ID = Identifier.of("ryuumon01-client", "ui.hover");
    private static final Identifier CLICK_ID = Identifier.of("ryuumon01-client", "ui.click");
    private static final Identifier SCROLL_ID = Identifier.of("ryuumon01-client", "ui.scroll");

    private static final SoundEvent HOVER_EVENT = SoundEvent.of(HOVER_ID);
    private static final SoundEvent CLICK_EVENT = SoundEvent.of(CLICK_ID);
    private static final SoundEvent SCROLL_EVENT = SoundEvent.of(SCROLL_ID);

    // Prevents hover-sound spam by only re-triggering when the hovered element changes.
    private Object lastHoveredElement = null;

    public void playHover(Object hoveredElement) {
        if (hoveredElement == lastHoveredElement) return;
        lastHoveredElement = hoveredElement;
        if (hoveredElement != null) {
            play(HOVER_EVENT, 1.6f);
        }
    }

    public void playClick() {
        play(CLICK_EVENT, 1.0f);
    }

    public void playScroll() {
        play(SCROLL_EVENT, 1.9f);
    }

    public void resetHoverState() {
        lastHoveredElement = null;
    }

    private void play(SoundEvent event, float pitch) {
        if (!UI_SOUND_ENABLED.getValue()) return;
        float volume = (float) (UI_SOUND_VOLUME.getValue() / 100.0);
        if (volume <= 0f) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getSoundManager() == null) return;

        // PositionedSoundInstance.master plays through the master channel, unaffected by
        // in-world distance falloff — correct for a screen-space UI sound.
        client.getSoundManager().play(
                PositionedSoundInstance.master(event, pitch, volume)
        );
    }
}
