package com.ryuumon01.client.setting;

import org.lwjgl.glfw.GLFW;

public class KeybindSetting extends Setting<Integer> {

    private boolean listening = false;

    public KeybindSetting(String name, String description, int defaultKeyCode) {
        super(name, description, defaultKeyCode);
    }

    public boolean isListening() {
        return listening;
    }

    public void startListening() {
        listening = true;
    }

    public void bind(int keyCode) {
        setValue(keyCode);
        listening = false;
    }

    public void unbind() {
        setValue(GLFW.GLFW_KEY_UNKNOWN);
        listening = false;
    }

    public String getKeyName() {
        if (getValue() == GLFW.GLFW_KEY_UNKNOWN) return "NONE";
        String name = GLFW.glfwGetKeyName(getValue(), 0);
        if (name != null) return name.toUpperCase();
        return switch (getValue()) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_DELETE -> "DEL";
            default -> "KEY_" + getValue();
        };
    }
}
