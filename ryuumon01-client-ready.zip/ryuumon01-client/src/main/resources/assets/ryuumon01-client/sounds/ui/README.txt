Place your three UI sound effect files here as .ogg:
  hover.ogg   - soft high-frequency pop, ~40-80ms
  click.ogg   - crisp mechanical click, ~50-100ms
  scroll.ogg  - subtle tick, ~30-60ms

Keep them short and low-volume at the source; SoundManager already scales
playback volume via the UI Sound Volume setting, so avoid baking in loudness.
Free short UI SFX can be sourced from CC0 sites like freesound.org (filter by
CC0 license) — just make sure whatever you use is license-compatible with
however you plan to distribute this mod.
